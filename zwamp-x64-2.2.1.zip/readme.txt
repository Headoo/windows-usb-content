The Z-WAMP Server Pack is a lightweight zero-install Web server package that
runs on Windows. The project aims to provide the latest production/stable
versions of Apache, MySQL, PHP, Adminer, MongoDB, MemCached, SQLite,
eAccelerator, and Alternative PHP Cache (APC) to boost server performance.

Z-WAMP is hosted by SourceForge. Grab the latest version of this software at
http://zwamp.sourceforge.net.

If you feel that the Z-WAMP Server Pack is one great addition to your Web
development arsenal and it saves you a lot of time and money, please consider
making a donation to the project. Aside from motivating the people who make
this package available to the world, it also helps keep the project alive and
up-to-date.
